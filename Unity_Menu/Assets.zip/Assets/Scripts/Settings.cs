public class Settings
{
    static public string playerName = "";
    static public bool soundOn = true;
    static public float volume = 1;
}
